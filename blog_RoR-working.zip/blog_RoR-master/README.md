# Live Example

run 'bundle exec' to update/install dependencies
run 'rails s' to start running a server on localhost:3000

Open your browser and navigate to 'localhost:3000'
