class ChangeUrlToBody < ApplicationRecord
end
