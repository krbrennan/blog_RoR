class EditLinksToHaveUrl < ApplicationRecord
end
