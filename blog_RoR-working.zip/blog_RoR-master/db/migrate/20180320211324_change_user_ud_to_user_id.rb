# class ChangeUserUdToUserId < ActiveRecord::Migration[5.1]
#   def change
#     rename_column :articles, :user_ud, :user_id
#   end
# end
