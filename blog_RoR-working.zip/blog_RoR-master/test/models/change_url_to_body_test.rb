require 'test_helper'

class ChangeUrlToBodyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
